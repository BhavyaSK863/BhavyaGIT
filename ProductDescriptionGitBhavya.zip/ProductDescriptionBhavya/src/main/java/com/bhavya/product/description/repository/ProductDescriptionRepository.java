package com.bhavya.product.description.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bhavya.product.description.entity.ProductDescriptionEntity;




@Repository
public interface ProductDescriptionRepository extends JpaRepository<ProductDescriptionEntity, Integer>{

}
