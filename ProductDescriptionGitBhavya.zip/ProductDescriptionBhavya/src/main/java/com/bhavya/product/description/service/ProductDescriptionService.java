package com.bhavya.product.description.service;

import java.util.Optional;

import com.bhavya.product.description.entity.ProductDescriptionEntity;




public interface ProductDescriptionService {

	public Optional<ProductDescriptionEntity> getById(Integer descId);
	public void addDescription(ProductDescriptionEntity description);
}
