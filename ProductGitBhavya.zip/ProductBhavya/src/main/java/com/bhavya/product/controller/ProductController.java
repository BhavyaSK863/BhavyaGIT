package com.bhavya.product.controller;




import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bhavya.product.entity.ProductEntity;
import com.bhavya.product.service.ProductServiceImplementation;
import com.bhavya.product.vo.ProductWithDescriptionVO;



@RestController
@RequestMapping("/product")
public class ProductController {
	
	@Autowired
	private ProductServiceImplementation productServiceImplementation;
	
	@GetMapping("/byid{id}")
	public Optional<ProductEntity>getProductById(@PathVariable Integer id){
		return productServiceImplementation.getById(id);
		
	}
	
	@GetMapping("/bytype/{type}")public List<ProductEntity>getProductByType(@PathVariable String type){
		return productServiceImplementation.getByType(type);
		
	}
	@PostMapping("/addproduct")
	public void addProduct(@RequestBody ProductEntity product){
		productServiceImplementation.addProduct(product);
		
	}
	@GetMapping("/productwithdescription/{id}")
	public ProductWithDescriptionVO getProductWithDescription(@PathVariable Integer id){
		return productServiceImplementation.getProductWithDescription(id);
		
	}
	
	
}
