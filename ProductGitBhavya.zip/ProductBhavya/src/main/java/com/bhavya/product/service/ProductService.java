package com.bhavya.product.service;


import java.util.List;
import java.util.Optional;

import com.bhavya.product.entity.ProductEntity;
import com.bhavya.product.vo.ProductWithDescriptionVO;



public interface ProductService {

	public Optional<ProductEntity> getById(Integer productId);
	public List<ProductEntity> getByType(String type);
	public void addProduct(ProductEntity product);
	public ProductWithDescriptionVO getProductWithDescription(Integer productId);
}
