package com.bhavya.product.vo;



import com.bhavya.product.entity.ProductEntity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProductWithDescriptionVO {
	
	private ProductEntity productEntity;
	private ProductDescriptionVO productDescription;
	public ProductEntity getProductEntity() {
		return productEntity;
	}
	public void setProductEntity(ProductEntity productEntity) {
		this.productEntity = productEntity;
	}
	public ProductDescriptionVO getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(ProductDescriptionVO productDescription) {
		this.productDescription = productDescription;
	}

	

}

